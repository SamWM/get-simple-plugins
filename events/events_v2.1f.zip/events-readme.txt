Copy events.php and php-helper folder into GetSimple plugins folder

== Usage ==

Adds events sidebar menu in admin section 'pages' to allow adding events.

Show events on page by editing the template and adding the following:
<?php echo events_list() ?>

Show the calendar (for navigation):
<?php echo events_calendar() ?>

Show upcoming events (e.g. in the sidebar):
<?php echo '<h2>Upcoming events</h2><div class="feature">'.upcoming_events($SITEURL.'events/', 'strong').'</div>' ?>

`upcoming_events` has three arguments: $base_url, $date_heading_tag, $limit
$base_url is the page the the links are on. $date_heading_tag is the tag to wrap the date in. $limit is how many events to show (default is set to three)